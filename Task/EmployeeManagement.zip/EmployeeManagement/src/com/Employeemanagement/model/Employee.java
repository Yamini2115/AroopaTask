package com.Employeemanagement.model;

public class Employee {
	protected int id;
	protected String emp_name;
	protected String department;
	protected String gender;
	protected String maritalStatus;
	protected String address;
	protected int salary;
	protected int EMP_ID;
	
	
	public Employee() {
	}
	
	public Employee(String emp_name, String department, String gender,String maritalStatus, String address,int salary){
		super();
		this.emp_name =emp_name;
		this.department= department;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.address=address;
		this.salary =salary;

	}
	
	public Employee(int id, String emp_name, String department, String gender,String maritalStatus,String  address,int salary,int EMP_ID) {
		super();
		this.id = id;
		this.emp_name = emp_name;
		this.department = department;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.address = address;
		this.salary=salary;
		this.EMP_ID = EMP_ID;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getemp_name() {
		return emp_name;
	}
	public void setemp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getdepartment() {
		return department;
	}
	public void setdepartment(String department) {
		this.department = department;
	}
	public String getgender() {
		return gender;
	}
	public void setgender(String gender) {
		this.gender = gender;
	}
	public String getmaritalStatus() {
		return  maritalStatus;
	}
	public void setmaritalStatus(String  maritalStatus) {
		this. maritalStatus =  maritalStatus;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address =  address;
	}
	public int getsalary() {
		return salary;
	}
	public void setsalary(int salary) {
		this.salary =  salary;
	}
	public int getEMP_ID() {
		return EMP_ID;
	}
	public void setEMP_ID(int  EMP_ID) {
		this. EMP_ID =  EMP_ID;
	}

}