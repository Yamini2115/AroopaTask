package com.Employeemanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Employeemanagement.model.Employee;


public class EmployeeDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/employee_management?useSSL=false&allowPublicKeyRetrieval=true";
	private String jdbcUsername = "root";
	private String jdbcPassword = "sabuu1521$yam";
     
	
	private static final String INSERT_SALARY_SQL = "insert into Salary(SALARY) values(?)";
	private static final String INSERT_EMPLOYEES_SQL = "insert into employees(EMP_NAME,DEPARTMENT,GENDER,MARITALSTATUS,ADDRESS,EMP_ID)values(?,?,?,?,?,?)";
	
	private static final String SELECT_SALARY_BY_EMP_ID = "select * from salary order by EMP_ID desc limit 1";

	private static final String SELECT_EMPLOYEES_BY_ID = "select EMP_NAME,DEPARTMENT,GENDER,MARITALSTATUS,ADDRESS from employees where ID =?";
	
	private static final String SELECT_ALL_EMPLOYEES = "select * from employees";
	private static final String SELECT_ALL_SALARY = "select * from salary";
	private static final String DELETE_EMPLOYEES_SQL = "delete from employees where ID = ?;";
	private static final String DELETE_SALARY_SQL_BY_EMPID = "delete from salary where EMP_ID = ?;";
	private static final String SELECT_EMP_ID_FROM_EMPLOYEE = "SELECT EMP_ID FROM employees WHERE ID=?;";
	private static final String SELECT_SALARY_BY_EMPID = "SELECT SALARY FROM Salary WHERE EMP_ID=?;";	
	
	private static final String UPDATE_EMPLOYEES_SQL = "update employees set EMP_NAME= ?,DEPARTMENT= ?, GENDER =? ,MARITALSTATUS= ?,ADDRESS= ? where ID = ?;";
	private static final String UPDATE_SALARY_SQL = "update salary set SALARY=? where EMP_ID = ?;";

	public EmployeeDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	
	public void insertEmployee(Employee employee) throws SQLException {
		
		System.out.println(INSERT_EMPLOYEES_SQL);
		try {
		 Connection connection = getConnection();
		 	PreparedStatement ps = connection.prepareStatement(INSERT_SALARY_SQL);
		 	
		 	ps.setInt(1,employee.getsalary());
		 	System.out.println(employee.getsalary());
		 	ps.executeUpdate();
		 	PreparedStatement ps2 = connection.prepareStatement(SELECT_SALARY_BY_EMP_ID);
		 	ResultSet rs = ps2.executeQuery();
		 	if(rs.next()) {
		 		int emp_id = rs.getInt("EMP_ID");
		 	
		 	
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_EMPLOYEES_SQL);
			preparedStatement.setString(1, employee.getemp_name());
			preparedStatement.setString(2, employee.getdepartment());
			preparedStatement.setString(3, employee.getgender());
			preparedStatement.setString(4, employee.getmaritalStatus());
			preparedStatement.setString(5, employee.getaddress());
			preparedStatement.setInt(6,emp_id);
			preparedStatement.executeUpdate();
		 	}
			
        } catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Employee selectEmployee(int id) {
		Employee employee = null;
		try { 
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_EMPLOYEES_BY_ID); 
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			  int emp_id = 0;
			  PreparedStatement ps2 = connection.prepareStatement(SELECT_EMP_ID_FROM_EMPLOYEE);
			  ps2.setInt(1,id);
			  ResultSet rs1 = ps2.executeQuery();
			  if(rs1.next())
			 	  emp_id = rs1.getInt("EMP_ID");
			  
			  PreparedStatement ps3 = connection.prepareStatement(SELECT_SALARY_BY_EMPID);
			  ps3.setInt(1,emp_id);
			  ResultSet rs2 = ps3.executeQuery();
			
			while (rs.next() && rs2.next()) {
				String emp_name = rs.getString("emp_name");
				String department = rs.getString("department");
				String gender = rs.getString("gender");
				String maritalStatus= rs.getString("maritalStatus");
				String address = rs.getString("address");
				int salary = rs2.getInt("salary");
				employee = new Employee(id, emp_name, department,gender,maritalStatus,address,salary,emp_id);//,salary,EMP_ID
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return employee;
	}

		public List<Employee> selectAllEmployees() {
		List<Employee> employees = new ArrayList<>();
		try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_EMPLOYEES);
			PreparedStatement ps1 = connection.prepareStatement(SELECT_ALL_SALARY);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			ResultSet rs1 = ps1.executeQuery();
			while (rs.next() && rs1.next()) {
				int id = rs.getInt("id");
				String emp_name= rs.getString("emp_name");
				String department= rs.getString("department");
				String gender = rs.getString("gender");
				String maritalStatus = rs.getString("maritalStatus");
				String address = rs.getString("address");
				int salary = rs1.getInt("salary");
				int EMP_ID = rs.getInt("EMP_ID");
				employees.add(new Employee(id, emp_name, department,gender,maritalStatus,address,salary,EMP_ID));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return employees;
	}

	public boolean deleteEmployee(int id) throws SQLException {
		boolean rowDeleted = false;
		try {
		  Connection connection = getConnection();

		  int emp_id = 0;
		  PreparedStatement ps2 = connection.prepareStatement(SELECT_EMP_ID_FROM_EMPLOYEE);
		  ps2.setInt(1,id);
		  ResultSet rs = ps2.executeQuery();
		  if(rs.next())
		 	  emp_id = rs.getInt("EMP_ID");
		  
		  PreparedStatement statement = connection.prepareStatement(DELETE_EMPLOYEES_SQL);
		  statement.setInt(1, id);
		  rowDeleted = statement.executeUpdate() > 0;
		  System.out.println("Employee Record deleted :" + rowDeleted);
		  
		  PreparedStatement statement1 = connection.prepareStatement(DELETE_SALARY_SQL_BY_EMPID);
	      statement1.setInt(1, emp_id);
	      System.out.println("Salary Delete Qury :" + statement1);
		  rowDeleted = statement1.executeUpdate() > 0;
		  System.out.println("Salary Record deleted :" + rowDeleted);
		}  catch (SQLException e) {
			printSQLException(e);
		}
		return rowDeleted;
	}

	public boolean updateEmployee(Employee employee) throws SQLException {
		boolean rowUpdated = false;
		try {
			Connection connection = getConnection();
			PreparedStatement statement1 = connection.prepareStatement(UPDATE_SALARY_SQL);
			statement1.setInt(1, employee.getsalary());
			statement1.setInt(2, employee.getEMP_ID());
			System.out.println(statement1);
			rowUpdated = statement1.executeUpdate() > 0;
			System.out.println("Updated Salary:"+ rowUpdated);
			PreparedStatement statement = connection.prepareStatement(UPDATE_EMPLOYEES_SQL);
			statement.setString(1, employee.getemp_name());
			statement.setString(2, employee.getdepartment());
			statement.setString(3, employee.getgender());
			statement.setString(4, employee.getmaritalStatus());
			statement.setString(5, employee.getaddress());
			statement.setInt(6, employee.getId());
			System.out.println(statement);
            rowUpdated = statement.executeUpdate() > 0;
            System.out.println("Updated Employees:"+ rowUpdated);
		}  catch (SQLException e) {
			printSQLException(e);
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

}




